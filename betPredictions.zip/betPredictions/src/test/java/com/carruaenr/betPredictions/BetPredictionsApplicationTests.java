package com.carruaenr.betPredictions;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BetPredictionsApplicationTests {

	@Test
	void contextLoads() {
	}

}
